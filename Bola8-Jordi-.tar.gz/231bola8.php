<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
Pregunta:
<input type="text" name="pregunta" id="pregunta" maxlength="50"><br>

<button type="submit">Haz Click¡</button>
<?php
$arrayRespuestas= array("oooh que sopresa","No me lo creo","Te creo")
$pregunt=document.getElementById("pregunta").value;
echo $arrayRespuestas[rand(0,2)];
?>
</body>
</html>
